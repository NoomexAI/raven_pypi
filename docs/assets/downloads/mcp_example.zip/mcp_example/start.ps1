param(
    [string]$RavenHome = (Join-Path $PSScriptRoot 'raven_home'),
    [switch]$Check,
    [switch]$McpServer,
    [string]$PythonExecutable
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$projectRoot = Split-Path -Parent $PSScriptRoot
# Resolve the activated environment once; Inspector's child receives the exact
# executable explicitly because its environment may not preserve activation.
if (-not $McpServer) {
    $PythonExecutable = (Get-Command python -CommandType Application -ErrorAction Stop | Select-Object -First 1).Source
}
$python = $PythonExecutable
$serverFile = Join-Path $PSScriptRoot 'server.py'
$RavenHome = [IO.Path]::GetFullPath($RavenHome)
$tokenFile = Join-Path $RavenHome 'temp\server_auth\bearer_token'
$tempDir = Join-Path $PSScriptRoot '.tmp'

if (-not $python -or -not (Test-Path -LiteralPath $python)) {
    throw 'Python was not found. Activate the virtual environment before running start.ps1.'
}
if (-not $McpServer) {
    $isVirtualEnvironment = & $python -c 'import sys; print(int(sys.prefix != sys.base_prefix))'
    if ($LASTEXITCODE -ne 0 -or $isVirtualEnvironment -ne '1') {
        throw 'Activate a Python virtual environment with the example dependencies before running start.ps1.'
    }
}

# Read only the bind address; the RAVEN CLI still validates all system settings.
$ravenHost = '127.0.0.1'
$ravenPort = 8765
$settingsFile = Join-Path $RavenHome 'system_settings\system_settings.json'
if (Test-Path -LiteralPath $settingsFile) {
    $settings = Get-Content -Raw -LiteralPath $settingsFile | ConvertFrom-Json
    if ($settings.host) { $ravenHost = $settings.host }
    if ($settings.port) { $ravenPort = [int]$settings.port }
}
if ($ravenHost -in @('0.0.0.0', '::')) { $ravenHost = '127.0.0.1' }
$ravenUrl = ([UriBuilder]::new('http', $ravenHost, $ravenPort)).Uri.AbsoluteUri.TrimEnd('/')

New-Item -ItemType Directory -Force -Path $tempDir | Out-Null
$env:TEMP = $tempDir
$env:TMP = $tempDir
$env:PYTHONDONTWRITEBYTECODE = '1'

# Inspector invokes this branch. Read credentials here instead of relying on
# Inspector to inherit custom environment variables. Write no text to stdout:
# it carries the MCP protocol, not launcher diagnostics.
if ($McpServer) {
    if (-not (Test-Path -LiteralPath $tokenFile)) {
        throw 'RAVEN token file is missing. Start the example with start.ps1 first.'
    }
    $env:RAVEN_URL = $ravenUrl
    $env:RAVEN_TOKEN = (Get-Content -Raw -LiteralPath $tokenFile).Trim()
    $utf8 = [Text.UTF8Encoding]::new($false)
    [Console]::InputEncoding = $utf8
    [Console]::OutputEncoding = $utf8
    $OutputEncoding = $utf8
    & $python $serverFile
    exit $LASTEXITCODE
}

$npx = (Get-Command npx.cmd -ErrorAction Stop).Source
$shell = (Get-Process -Id $PID).Path
$env:npm_config_cache = Join-Path $PSScriptRoot '.npm-cache'
$env:MCP_STORAGE_DIR = Join-Path $tempDir 'inspector-storage'
$env:MCP_INSPECTOR_SECRET_STORE = 'memory'
$env:MCP_INSPECTOR_PERSIST_TOKENS = 'none'
# A pre-existing catalog setting conflicts with an explicitly supplied target.
Remove-Item Env:MCP_CATALOG_PATH -ErrorAction SilentlyContinue

function Test-RavenConnection {
    if (-not (Test-Path -LiteralPath $tokenFile)) { return $false }
    try {
        $token = (Get-Content -Raw -LiteralPath $tokenFile).Trim()
        if (-not $token) { return $false }
        $response = Invoke-RestMethod -Uri "$ravenUrl/api/v1/runtime" `
            -Headers @{ Authorization = "Bearer $token" } -TimeoutSec 2
        return $response.started -eq $true
    } catch {
        return $false
    }
}

$ravenProcess = $null
try {
    if (Test-RavenConnection) {
        Write-Host "Using the RAVEN server already running at $ravenUrl."
    } else {
        Write-Host "Starting RAVEN at $ravenUrl ..."
        # Invoke Python directly so the tracked PID is the server itself,
        # rather than the nraven.exe console-entry-point wrapper.
        $ravenProcess = Start-Process -FilePath $python -ArgumentList @(
            '-m', 'nraven.server.cli', 'serve', '--home', ('"{0}"' -f $RavenHome)
        ) -WorkingDirectory $projectRoot -WindowStyle Hidden -PassThru `
            -RedirectStandardOutput (Join-Path $tempDir 'raven.stdout.log') `
            -RedirectStandardError (Join-Path $tempDir 'raven.stderr.log')

        $deadline = [DateTime]::UtcNow.AddSeconds(60)
        while (-not (Test-RavenConnection)) {
            if ($ravenProcess.HasExited) {
                throw "RAVEN exited during startup. See $tempDir\raven.stderr.log. If another server owns the port, stop it first."
            }
            if ([DateTime]::UtcNow -gt $deadline) {
                throw "RAVEN did not become ready. See $tempDir\raven.stderr.log."
            }
            Start-Sleep -Milliseconds 250
        }
    }

    # The wrapper reads the token inside the child process. No credential is
    # placed in these arguments, copied into Inspector, or saved in a catalog.
    $inspectorArgs = @('@modelcontextprotocol/inspector@2.12.0')
    if ($Check) { $inspectorArgs += @('--cli', '--method', 'tools/list') }
    $inspectorArgs += @(
        '--', $shell, '-NoProfile', '-ExecutionPolicy', 'Bypass',
        '-File', $PSCommandPath, '-RavenHome', $RavenHome,
        '-McpServer', '-PythonExecutable', $python
    )
    Write-Host 'Launching RavenMCP in MCP Inspector. Press Ctrl+C here to stop.'
    & $npx @inspectorArgs
    if ($LASTEXITCODE -ne 0) { throw "Inspector exited with code $LASTEXITCODE." }
} finally {
    if ($null -ne $ravenProcess -and -not $ravenProcess.HasExited) {
        Write-Host 'Stopping the RAVEN process started by this launcher.'
        $ravenProcess.Kill()
        $ravenProcess.WaitForExit()
    }
    # Do not stop a server that was already running before this launcher.
}
