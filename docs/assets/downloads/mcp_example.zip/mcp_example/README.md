# RavenMCP

This example connects an MCP client to a separately running RAVEN HTTP server.
It currently exposes `configure_models`, `create_knowledge`, `ingest_file`,
`list_knowledges`, `create_conversation`, `list_conversations`, and `ask_raven`.
The example is Ollama-only; cloud providers are deliberately outside its scope.
This is an educational bridge, not a complete hosted MCP service.

## Requirements

- Python 3.11 or newer.
- The dependencies in `requirements.txt` installed in the example's environment.
- RAVEN v0.2.0 with its server extra installed (included in `requirements.txt`).
  Its HTTP server is started by the launcher or separately, as explained below.
- A running Ollama service with the generation and embedding models installed
  before model configuration. RAVEN v0.2.0's documented Ollama version is 0.34.2.
- Node.js and npm available on `PATH` when using MCP Inspector. They are not
  required when Codex or another MCP client launches the bridge directly.

**The PowerShell launcher and the commands below were tested on Windows.**
The Python bridge uses standard stdio and HTTP, but `start.ps1` is a Windows
convenience launcher, not a cross-platform launcher. Other operating systems
need their own shell commands, interpreter paths, environment setup, and
process management.

Knowledge and conversation creation/listing do not require configured models.
For configuration, Ollama must already be running with an LLM and an embedding
model installed. RAVEN connects to Ollama; it does not start or stop its process.
Choose an LLM with tool-calling support. Model configuration is runtime state:
configure the pair again after restarting RAVEN. Knowledge and conversations
remain on disk.

## Download the example

Extract the archive so its five source/documentation files remain together in
`mcp_example/`. The RAVEN repository is not required: RAVEN is installed from
PyPI through `requirements.txt`.

The commands below assume the terminal is in the **parent of `mcp_example/`**:

```text
raven-demo/
├── mcp_example/
│   ├── README.md
│   ├── requirements.txt
│   ├── server.py
│   ├── client.py
│   └── start.ps1
└── .venv/                 # Created by the commands below.
```

Create and activate a Python virtual environment, then install the requirements:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r .\mcp_example\requirements.txt
```

An existing activated virtual environment can be used instead.

## One-command startup

Activate a virtual environment containing RAVEN's server dependencies and this
example's requirements. Then, from PowerShell in the parent of `mcp_example/`:

```powershell
.\mcp_example\start.ps1
```

The launcher uses the activated environment's `python`, starts RAVEN with
`raven_home/` beside `start.ps1`, waits for an authenticated runtime response,
and launches MCP Inspector. This startup check does not configure models.
If that home's server is already running and reachable, it reuses it instead.
Connect to the displayed server in Inspector and open its Tools panel.

The default HTTP address is `http://127.0.0.1:8765`. The launcher reads `host`
and `port` from the selected home's `system_settings/system_settings.json`
when present. Stop any unrelated server using the same port before launching
another home, or configure a different port for it.

Keep the virtual environment activated. The launcher reads RAVEN's service
token automatically; no token entry is needed in Inspector. Inspector is
downloaded through `npx` when needed, without a separate global installation.

Keep the launching terminal open. Press Ctrl+C there to stop Inspector. On a
normal launcher exit, a RAVEN process started by the launcher is terminated;
a reused server is left running. This stop is process termination, not a
guaranteed graceful drain of active operations. Finish work before exiting.
Closing the browser tab alone does not stop Inspector.

To verify discovery without opening the browser:

```powershell
.\mcp_example\start.ps1 -Check
```

To use a different RAVEN home:

```powershell
.\mcp_example\start.ps1 -RavenHome E:\raven-data
```

The launcher is for the local, single-user example. Hosted identity routing is
outside its scope. If PowerShell blocks scripts, the launcher can be invoked
with a process-scoped policy instead of changing the machine's policy:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\mcp_example\start.ps1
```

## Manual startup (alternative)

### Start RAVEN

From the parent of `mcp_example/`, in an activated environment in one PowerShell
terminal:

```powershell
nraven serve --home .\mcp_example\raven_home
```

This home stores the example's data. Knowledge from another RAVEN home is not
copied into it.

### Configure and launch the bridge

For an MCP client that launches `server.py` directly, supply the following
environment variables to **the child process it launches**:

```powershell
$env:RAVEN_URL = "http://127.0.0.1:8765"
$env:RAVEN_TOKEN = (Get-Content -Raw .\mcp_example\raven_home\temp\server_auth\bearer_token).Trim()
```

Run these commands from the parent of `mcp_example/` when setting up a client
that inherits the terminal environment. Setting variables in a terminal does
not guarantee that a separately opened desktop client inherits them.

The token changes when RAVEN restarts. Keep it private and reconnect the bridge
after a restart. `RAVEN_URL` must contain only the HTTP(S) origin, without a path,
query, or embedded credentials. Use HTTPS across an untrusted network.

`RAVEN_USER_ID` is optional. Leave it unset for the default local identity.
For a trusted hosted integration, it may supply the UUID already authorized by
the surrounding host. It is not an end-user login mechanism and is never a tool
argument. Restart the bridge after changing its connection configuration.

Set the MCP client's command to the virtual environment's Python executable
and its argument to the absolute path to `mcp_example/server.py`. Running the
script alone waits for an MCP client; it does not open an interface.

For Inspector, use `start.ps1` even if RAVEN was started manually: it reuses
the running server and supplies its token automatically. Keep Inspector local
and keep its own access token private.

## Connect to Codex instead of Inspector

Codex can launch the bridge directly. Inspector and Node.js are not needed
for this route.

1. Start RAVEN in an activated PowerShell terminal and keep it running:

   ```powershell
   nraven serve --home .\mcp_example\raven_home
   ```

2. Open the parent folder as the project in Codex. Create `.codex/config.toml`
   inside that parent folder. The following example assumes it is
   `E:/raven-demo`; replace every path with the actual extracted folder, Python
   executable, and RAVEN home:

   ```toml
   [mcp_servers.RavenMCP]
   command = "powershell.exe"
   args = [
       "-NoProfile",
       "-ExecutionPolicy", "Bypass",
       "-File", "E:/raven-demo/mcp_example/start.ps1",
       "-RavenHome", "E:/raven-demo/mcp_example/raven_home",
       "-McpServer",
       "-PythonExecutable", "E:/raven-demo/.venv/Scripts/python.exe",
   ]
   cwd = "E:/raven-demo"
   startup_timeout_sec = 30
   tool_timeout_sec = 660
   ```

   To find the activated environment's interpreter before filling in the file:

   ```powershell
   python -c "import sys; print(sys.executable)"
   ```

3. Trust the project if prompted, then restart Codex to load the connection.
   Ask it to use RavenMCP's `list_knowledges` tool. It should return the current
   knowledge list, or an empty `items` list if none has been created yet.

**`-McpServer` is bridge-only mode:** it reads the token and starts `server.py`;
it does not start RAVEN or Inspector. Keep this switch in the Codex configuration
and start RAVEN separately.

Do not put the service token in the TOML file; the launcher reads it from the
selected home. The tool timeout allows long-running ingestion and chat calls.
After restarting RAVEN, reconnect RavenMCP to load the new token. Closing Codex
does not stop the separately started RAVEN server.

Keep the local `.codex/` folder out of version control. To remove this connection,
delete its `RavenMCP` entry and restart Codex. For the current
configuration options, see the [official Codex MCP documentation](https://developers.openai.com/codex/mcp).

## Demonstration workflow

In Inspector's Tools panel, or through the connected AI client:

1. Call `configure_models` with the installed LLM and embedding model names.
2. Call `list_knowledges` to discover existing knowledge, or `create_knowledge`
   when a new knowledge is needed.
3. Call `ingest_file` with that knowledge name and an absolute document path.
   Wait for success before asking about the new document.
4. Call `create_conversation` with the knowledge name for a local conversation,
   or omit it for a global conversation.
5. Call `ask_raven` with the returned conversation ID and a document question.
6. Reuse that conversation ID for follow-ups. `list_conversations` can find it
   again by title without creating another conversation.

Models must be configured before ingestion or chat, but creating/listing
knowledge and conversations does not depend on them. Calling `ask_raven`
delegates the question to RAVEN's own agent and models, not the MCP client's
model. This example returns one completed answer rather than a live token stream.

## Tool inputs

Both `llm_model` and `embedding_model` are required. `configure_models`, using
names already installed in Ollama:

```json
{"llm_model": "qwen3:8b", "embedding_model": "bge-m3"}
```

Replace those example names with installed models suitable for the machine.
The bridge builds the two Ollama model specifications and submits them to
`POST /api/v1/provider/models/configure`. RAVEN prepares the adapters and
preloads their models; replaced Ollama models may be unloaded.

The tool waits for completion and returns `operation_id`, `task_id`, `status`,
and the submitted model pair.

Configuration, ingestion, and chat wait up to ten minutes. Cancellation or
expiry requests backend cancellation when the operation ID is known, but does
not guarantee rollback. If a call fails, check its reported operation before
repeating it: work may already have been saved. There is no automatic retry.
Increase the MCP client's request timeout if it stops waiting too early.

**Keep the embedding model fixed after ingestion.** Documents embedded by one
model cannot simply be searched using a different embedding model.

`create_knowledge` requires `name`; `user_summary` is optional:

```json
{"name": "engineering", "user_summary": "Engineering reference documents"}
```

Returns RAVEN's saved knowledge metadata. `user_summary` is optional and defaults
to an empty string. A duplicate name produces a tool error for HTTP 409; existing
knowledge is not overwritten.

`ingest_file` requires both `knowledge_name` and `file_path`, after configuring
models and creating the knowledge:

```json
{
  "knowledge_name": "engineering",
  "file_path": "E:/documents/Reaction_wheel.txt"
}
```

Replace the example path with an actual absolute path on the machine running
the MCP bridge, not a path on a remote RAVEN server. The bridge uploads the
selected document to RAVEN.

Only `.txt`, `.md`, `.pdf`, and `.docx` are accepted, with a 64 MiB bridge limit;
RAVEN may enforce a smaller configured limit. Files are buffered in memory for
this small example. Run it only with trusted local MCP callers because they can
choose readable files to send to RAVEN. Do not expose it as an unrestricted
hosted file-upload gateway.

The tool waits for ingestion completion and returns the operation/task IDs,
knowledge name, and filename. Empty, missing, unsupported, oversized, duplicate,
or failed ingestions produce tool errors rather than success. RAVEN manages
the uploaded source's retention and database writes; the bridge does not open
its storage directly. Reusing a filename does not silently overwrite a file.

`list_knowledges`:

```json
{"limit": 10}
```

An empty knowledge base returns `{"items": [], "next_cursor": null}`. For a
later page, pass the returned `next_cursor` as `after_name`. The bridge limits
`limit` to 1–100; the RAVEN server may have a smaller configured maximum. Both
arguments are optional: `limit` defaults to 10 and `after_name` defaults to null.

`create_conversation`, global:

```json
{}
```

`create_conversation`, local, after a knowledge named engineering has been
created through RAVEN:

```json
{"knowledge_name": "engineering"}
```

The result includes the conversation ID and scope type. `knowledge_name` is
optional and defaults to null (global); an empty string does not mean global.
Save the ID for chat and follow-ups. Each successful call creates a separate
conversation. If a call is interrupted, check `list_conversations` before
creating another one.

`list_conversations`, to find an existing conversation:

```json
{"limit": 10}
```

Returns `items` and `next_cursor`. Each item includes `conversation_id`, `title`,
`type`, `knowledge_name`, `pinned`, `created_at`, `is_titled`, and `schema_version`.
The list is newest-first and does not include messages. A new untitled
conversation appears as `New Conversation`; RAVEN normally generates its title
after a completed turn. Listing does not require models to be configured.

If `next_cursor` is not null, pass its exact value as `after_conversation_id`:

```json
{"limit": 10, "after_conversation_id": "c36c45ac5575"}
```

The ID above is illustrative; use the cursor returned by the preceding page.
An empty list is `{"items": [], "next_cursor": null}`. The bridge accepts page
sizes of 1–100; the server may impose a smaller maximum. Pick the desired
conversation by title and pass its `conversation_id` to `ask_raven`. Both
arguments are optional: `limit` defaults to 10 and `after_conversation_id`
defaults to null.

`ask_raven` requires both `conversation_id` and a nonblank `user_query` of at
most 32768 characters, after creating or finding a conversation:

```json
{
  "conversation_id": "c36c45ac5575",
  "user_query": "Using the engineering knowledge, what is a reaction wheel?"
}
```

Use the actual `conversation_id` returned by `create_conversation`. The bridge
submits a turn with `retrieval_mode: "auto"`, waits for its operation to finish,
and fetches the persisted turn. RAVEN's agent decides which tools to use within
that conversation's local/global scope. The MCP tool does not select retrieval
strategies or implement a second agent loop.

The result contains `conversation_id`, `turn_id`, `operation_id`, `task_id`,
`status`, `response`, `evidence`, and `iteration_limit_reached`. Evidence items
identify `knowledge_name`, `file_name`, and `section_id`. A casual reply may have
an empty evidence list. Thinking, internal tool traces, and reconstructed file
contents are deliberately excluded from the MCP response.

Ask follow-ups using the same conversation ID. RAVEN persists its history and
handles memory; the bridge does not keep its own chat history. Concurrent turns
in the same conversation are rejected. The answer is returned as a completed
MCP tool result, not token-by-token streaming. If observing a turn fails, retain
its reported IDs and inspect it before starting another turn.

## Files

- `server.py`: MCP registration, connection configuration, and client lifecycle.
- `client.py`: request mapping and safe HTTP error translation.
- `requirements.txt`: the example's direct Python dependencies.
- `start.ps1`: local RAVEN/Inspector launcher, or bridge-only launcher with
  `-McpServer` for a client such as Codex.
- `README.md`: setup, tool inputs, lifecycle boundaries, and limitations.

The Python bridge does not own RAVEN's lifecycle or schedule storage cleanup.
The convenience launcher owns only the RAVEN process it starts. With manual
startup, stop Inspector and the RAVEN server separately when finished.

Keep generated `raven_home/` data, credentials, and logs private.
