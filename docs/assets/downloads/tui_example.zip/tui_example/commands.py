"""The demo's command vocabulary; backend handlers are added in later stages."""

from dataclasses import dataclass



@dataclass(frozen=True)
class Command:
    path: str
    description: str
    stage: int



COMMANDS = (
    Command("/help", "Show commands and keyboard shortcuts", 1),
    Command("/knowledges", "List knowledges", 2),
    Command("/knowledges/create", "Create a knowledge", 2),
    Command("/knowledges/<name>", "Show a knowledge and its files", 2),
    Command("/knowledges/<name>/ingest", "Ingest a local document", 3),
    Command("/models", "Show configured LLM and embedding model", 3),
    Command("/models/configure", "Configure the model pair", 3),
    Command("/providers/ollama/models", "List installed Ollama models", 3),
    Command("/conversations", "List conversations", 4),
    Command("/conversations/create", "Create a conversation", 4),
    Command("/conversations/<id>", "Open a conversation", 4),
    Command("/sources", "Inspect the latest answer's sources", 6),
)


def matching_commands(prefix: str, knowledge_names: list[str] | tuple[str, ...] = ()) -> list[Command]:
    """Suggest runnable paths, not placeholder names or imaginary resources."""
    choices = [
        command for command in (*COMMANDS, *(
            command for name in knowledge_names for command in (
                Command(f"/knowledges/{name}", "Show this knowledge and its files", 2),
                Command(f"/knowledges/{name}/ingest", "Ingest a document into this knowledge", 3),
            )
        ))
        if "<" not in command.path and command.path.casefold().startswith(prefix.casefold())
    ]
    return sorted(choices, key=lambda command: command.path.casefold() != prefix.casefold())


def resolve_command(text: str) -> Command | None:
    """Resolve both fixed commands and resource routes without calling RAVEN."""
    if not text.startswith("/") or any(character.isspace() for character in text):
        return None
    parts = text.split("/")
    for command in COMMANDS:
        pattern = command.path.split("/")
        if len(parts) == len(pattern) and all(
            (bool(actual) and "<" not in actual and ">" not in actual)
            if expected.startswith("<") else actual.casefold() == expected
            for actual, expected in zip(parts, pattern)
        ):
            return command
    return None


def help_text() -> str:
    entries = "\n".join(f"{command.path}\n  {command.description}" for command in COMMANDS)
    return (
        f"{entries}\n\n"
        "Type / to browse commands; continue typing without a space to filter.\n"
        "Up/Down: choose · Enter/click: run · Tab: complete · Escape: dismiss\n"
        "Shift+Enter: newline · Ctrl+L: focus input · Ctrl+C: quit\n\n"
        "Replace <name> or <id> with a real value. Knowledge creation, listing, "
        "and details are connected to RAVEN. Use /models/configure before ingestion "
        "or chat. Models load only when you configure them. Use Attach or "
        "/knowledges/<name>/ingest to ingest a document. Use /conversations/create "
        "to start a global conversation or optionally choose one knowledge, then /conversations to "
        "open saved history by title. Send a message to chat; retrieval is automatic. "
        "Stop cancels the active response. View sources below an answer, or use "
        "/sources for the latest source-backed response in the current view."
    )
