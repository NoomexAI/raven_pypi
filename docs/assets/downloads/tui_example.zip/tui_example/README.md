# RAVEN TUI demo — documents and conversations

This example uses RAVEN's Python API and Textual to demonstrate knowledge
creation, document ingestion, conversation-backed chat, and source inspection.
It runs locally as a Python application; no RAVEN HTTP server is needed.

The interface is intentionally small. Slash commands open forms and clickable
lists, while ordinary messages go to the active conversation. RAVEN handles
document processing, agent execution, memory, persistence, and reconstruction.
The demo is not a complete administration client or a production application.

## Install and run

Requirements:

- Python 3.11, including the Windows `py` launcher for the commands below.
- VS Code with an integrated PowerShell terminal. Use this terminal for the
  demo so Shift+Enter is reported separately from Enter.
- Ollama 0.34.2 for the local model setup. Install Ollama separately; the Python
  requirements do not install or start its service.
- Disk space for dependencies, model weights, and application data, plus
  sufficient RAM and, when using GPU acceleration, GPU memory for the models.

Extract the archive into a working directory. It contains a top-level
`tui_example/` folder. Keep its Python files, `styles.tcss`, and
`requirements.txt` together; `app.py` cannot run by itself.

Open the **parent directory containing `tui_example/`** in VS Code and open an
integrated PowerShell terminal there. Run all commands below from that parent
directory, not from inside `tui_example/`.

Create an isolated environment and install the dependencies:

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r .\tui_example\requirements.txt
```

The dependency file installs RAVEN `0.2.0` and Textual `8.2.8`. The optional
RAVEN server extra is unnecessary. Each command uses the environment's Python
explicitly, so activation and PowerShell execution-policy changes are not needed.

After installation finishes, launch the application:

```powershell
.\.venv\Scripts\python.exe -B .\tui_example\app.py
```

Wait for **Ready**, then enter `/help` to see the commands. No models are loaded
at startup; configure them before ingestion or chat. Knowledge and conversation
management can be used without models.

The demo always uses `raven_home/` beside `app.py` as its RAVEN home. Startup
creates this directory if it does not exist and preserves existing contents.
There is no `--home` argument, and the location does not depend on the current
working directory. This path is passed to `Raven` explicitly.

Press Ctrl+C to close RAVEN and its databases gracefully. Existing knowledges
and conversations remain available after restarting the demo.

## Configure models

1. Open Ollama and leave its service running at `http://127.0.0.1:11434` for
   the local setup below. If starting it manually, run `ollama serve` in a
   separate terminal; do not start a second instance if the service is active.
   RAVEN does not start or stop the Ollama process.
2. Enter `/providers/ollama/models` to see installed model names. Listing does
   not load models into memory.
3. Enter `/models/configure`. Fill in both roles: provider and model name,
   plus an optional API key **environment-variable name** for cloud models.
   For a local example, use provider `ollama` for both roles, LLM `gemma4:e2b`,
   and embedding model `bge-m3:latest`. Leave both API key references blank.
4. Click Configure, or move through the fields with Enter and submit from the
   last field. The transcript shows compact progress from RAVEN's operation
   events. Existing Ollama models are reused; missing models are downloaded.
   Replaced local models are unloaded and the new pair is preloaded.
5. `/models` shows the configured pair. This is not a live residency/VRAM
   monitor, and configuring cloud models does not preload remote hardware or
   guarantee that future API requests will succeed.

The form is side by side in wide terminals and stacks in narrower terminals;
Tab/Enter follows LLM fields, then embedding fields. Cancel dismisses an idle
form. During configuration its controls are disabled, but the composer and
`/help` remain usable. Ctrl+C closes the demo and cancels unfinished work.

### Alternative: use a cloud LLM

The LLM can come from a provider supported by RAVEN's LiteLLM adapter. Select a
model with tool-calling support and ensure the provider account has access to
it. No particular cloud provider is required. Quotas and charges depend on the
selected service.

The application inherits credentials from its launching terminal. If the key
is not already in that environment, close the demo with Ctrl+C, then run these
commands in the same PowerShell terminal:

```powershell
$env:RAVEN_DEMO_API_KEY = [System.Net.NetworkCredential]::new(
    "", (Read-Host "Cloud provider API key" -AsSecureString)
).Password
.\.venv\Scripts\python.exe -B .\tui_example\app.py
```

Enter the secret only at the prompt. The command sets a variable for the current
terminal session; it does not save a credential file. Avoid printing its value
or including it in screenshots. The demo does not automatically load `.env`.

Open `/models/configure` and complete the LLM fields:

| Field | Value |
| --- | --- |
| Provider | The service's LiteLLM identifier, such as `openai`, `anthropic`, or `gemini`. These are examples, not an exhaustive list. |
| Model name | The selected provider's model identifier, with tool-calling support. |
| API key reference | `RAVEN_DEMO_API_KEY` |

Use the [LiteLLM provider documentation](https://docs.litellm.ai/docs/providers)
to find the appropriate provider identifier and model name. Provider identifiers
are routing values, not necessarily company names.

Replace the `YOUR_API_KEY` placeholder with the environment-variable **name**,
not the secret. An existing variable can also be referenced by entering its name.
Keep the embedding role as `ollama` / `bge-m3:latest` with an empty key reference,
and leave Ollama running for that role. Then select **Configure**.

**Choose the embedding model before ingestion. Existing vectors cannot be reused
with a different embedding model.** The backend validates persisted embedding
compatibility when changing the configured pair.

Model configuration is runtime state: configure again after reopening the demo.
Ollama downloads remain installed independently of the demo's `raven_home/`.
Ollama owns local residency and its expiry; closing RAVEN does not shut down that
external service. There are deliberately no separate preload/unload commands.

## Try the knowledge workflow

1. Enter `/knowledges/create`. Fill in a name such as `engineering` and an
   optional summary, then click Create. Enter moves from name to summary;
   Enter in the summary submits. Cancel dismisses the form.
2. Enter `/knowledges`. Click a knowledge to open its details, or focus the list
   with Tab and use Up/Down then Enter. Each knowledge shows its **file count**.
3. Enter `/knowledges/engineering` to open the same view directly. It shows the
   summary, creation time, and ingested files (initially none).
4. If `engineering` already exists from an earlier run, open it rather than
   creating it again. Duplicate or missing names produce visible errors without
   closing the application.
5. Close and restart the demo to return to the saved knowledge.

Names in this demo use letters, numbers, underscores, and hyphens. `create` is
reserved for the create command. Knowledge names also appear in slash suggestions.
Browsing knowledge details does not change conversation scope or Attach's default
target. With a local conversation open, Attach defaults to its knowledge;
otherwise it asks which knowledge should receive the document.

## Ingest a document

Download the sample document
[Reaction_wheel.txt](https://noomexai.github.io/raven_pypi/assets/downloads/test_files/Reaction_wheel.txt)
and save it in the **parent directory containing `tui_example/`**, alongside
the `.venv/` directory created above. If the browser displays the text, save it
as plain text with that exact filename, not as an HTML page.

Additional examples are available:

- [EPS.txt](https://noomexai.github.io/raven_pypi/assets/downloads/test_files/EPS.txt)
  — electrical power-system conditions and responses.
- [Clinical.txt](https://noomexai.github.io/raven_pypi/assets/downloads/test_files/Clinical.txt)
  — clinical terminology and numerical conditions.

These are illustrative inputs, not validated engineering or medical guidance.
Use `Reaction_wheel.txt` for the questions below; ingest the others separately
to explore additional documents.

First create a knowledge and configure both models. Then either:

- Enter `/knowledges/engineering/ingest`. The target is fixed to `engineering`.
- Click **Attach**. With a local conversation open, its knowledge is the fixed
  target; otherwise choose a target knowledge from the dropdown.

Enter a local path and click **Ingest**, or press Enter in the path field. With
the sample saved beside `tui_example/`, enter:

```text
Reaction_wheel.txt
```

Absolute paths, spaces, and a matching pair of surrounding quotes are supported.
Relative paths resolve from the launch directory, not from
`raven_home/`. Accepted types are `.txt`, `.md`, `.pdf`, and `.docx`. The original
file is read, not moved. Parsing PDFs/DOCX may need Docling's model assets on the
first run. With a cloud LLM, document sections are sent to that
provider for metadata extraction; local vectors do not make cloud inference local.

The transcript shows RAVEN's actual progress stages: source validation/snapshot,
parsing, semantic sectioning, metadata extraction, chunking, embedding, vector
storage, and metadata commit. Counts such as `1/2` apply to the displayed stage,
not a fabricated overall completion percentage. An activity indicator runs while
the operation is active. Repeated updates replace the current stage line; only
the latest eight stage entries are retained in the UI.

Click **Stop ingestion** to request cancellation. The UI waits for the backend's
safe cancellation/cleanup, then restores the form. Parsing or an atomic database
write may need time to finish its safe boundary. Cancellation does not undo a
file already committed; the refreshed file list shows any completed writes.
Use Cancel on an idle form to dismiss it without starting ingestion.

Success shows file/section/chunk counts and refreshes knowledge details and
earlier knowledge-list file counts. A failed details refresh is reported
separately and does not turn successful ingestion into a failed ingestion.
Missing paths, unsupported formats, missing models, and duplicate files show
errors without closing the app. Edit the form and try again as appropriate;
re-submission is a new operation, not the backend's durable retry API.

Only one backend action runs at a time in this demo. The composer and `/help`
stay usable during ingestion; conflicting actions are rejected until it finishes.
No conversation or model scope is changed by ingesting a document.

## Find and open conversations

1. Models, ingested files, and knowledges are not required just to create or
   browse conversations.
2. Enter `/conversations/create`, then click **Create** for the default
   **Global · All knowledges** scope. Optionally choose a specific knowledge to
   create a local conversation restricted to it.
   Use Tab/Enter to operate the selector and buttons from the keyboard. Cancel
   dismisses the form. Leaving the global option selected passes no knowledge
   binding to RAVEN.
3. The conversation opens immediately. The header shows its title and scope;
   an empty conversation shows **No messages yet**. RAVEN starts it with the title
   `New Conversation`; RAVEN generates a title during its first chat turn.
   Creating or opening a conversation itself does not send
   messages to a model.
4. Enter `/conversations` to see saved conversations, newest first. Entries show
   the title, scope, shortened ID, and creation time. Click an entry, or focus the
   list with Tab and use Up/Down then Enter. Full IDs are retained internally;
   no UUID needs to be memorized. Existing global conversations can also be opened.
5. `/conversations/<id>` opens the same view directly using the full ID. The full
   ID is shown in the history heading. Successfully opening a conversation
   replaces the workspace contents, so histories from different conversations
   are not mixed together. Slash commands and unsent drafts
   are not saved as conversation history.
6. The history is RAVEN's **canonical, uncompacted transcript**, not the summary
   used for the model's context. Saved user/assistant text is displayed in order.
   Saved tool calls/results are shown as concise activity; raw retrieval payloads
   are omitted, and thinking/system-context messages are not shown as chat text.
7. Close and reopen the app, then use `/conversations` to reopen the saved chat.
   The app does not automatically restore a selected conversation on startup.

The active conversation remains selected when inspecting knowledges or model
settings. Browsing a different knowledge never changes its scope; Attach still
uses the active local conversation's knowledge. A missing ID or failed history
read leaves the previous selection and transcript intact, with an error below.
If creation succeeds but opening fails, the UI reports that separately; use
`/conversations` to reopen it rather than creating a duplicate.

## Chat with the documents

Configure both models, ingest a document, and open a conversation scoped to that
knowledge, or a global conversation to search across the knowledge base. Type a
question and press Enter or click **Send**. For the sample
`Reaction_wheel.txt`, try:

```text
Use retrieval to search engineering. According to Reaction_wheel.txt, what is
the safe-hold execution window in milliseconds? Give the number and name the file.
```

Retrieval is `auto`: the agent chooses among the tools allowed by the conversation
scope. A local conversation cannot search other knowledges. Global conversations
can use global retrieval or target a named knowledge with local retrieval tools.
Small models may
answer from general knowledge or choose tools imperfectly; explicitly asking them
to use retrieval makes this demonstration more reliable. The TUI does not force
a tool or change the harness prompt.

- Answer text streams into a RAVEN response card.
- **Thinking**, if the provider emits thinking events, is separate and collapsed
  by default. Expand it to inspect the current turn; it is not saved as chat text.
- Tool calls/results show the step, name, and running/done/failed state. A failed
  tool may be recoverable by the agent. Raw retrieval contexts are not printed.
- The activity indicator/status also shows context compaction, source
  reconstruction, and saving. Source-backed responses have a **View sources** button.
- **Saved to conversation** appears only after the session confirms completion,
  including persistence—not merely when answer generation ends. A short title is
  generated automatically by RAVEN and the header is refreshed.

Ask a follow-up in the same conversation. Each turn uses a temporary RAVEN
session over that conversation; RAVEN manages context/memory and saves the user
message, tool exchanges, and answer. Reopen the conversation (or restart the app)
to inspect its persisted transcript. Commands and rejected drafts are never saved
as chat messages. A missing active conversation or model configuration produces a
helpful message and leaves the draft intact.

While responding, **Send becomes Stop**, even when the input is empty. Click it
to cancel the native session run and wait for safe cleanup. Partial text remains
visible and is labelled incomplete; cancellation does not undo an already
committed turn. Reopen the conversation to see what was actually saved. Errors
are likewise labelled, not presented as successfully saved answers. Send a fresh
message after cleanup.

Only one backend action runs at once in this demo. During a response, Attach is
disabled; conversation switching, model changes, and other mutations are rejected.
Drafting and `/help` remain available; pressing Enter on another message does
not start an overlapping turn or discard that draft. Ctrl+C cancels the response
and closes RAVEN's resources. The demo never stops the external Ollama service.

## Inspect an answer's sources

After a source-backed turn is saved, click **View sources** below that answer.
Each button belongs to that specific conversation and turn, not the latest chat
operation. Older answers keep their own buttons after reopening the conversation
or restart the app. Casual answers, failed tools, and empty retrievals do not get
buttons. Content-reading navigation tools can provide source evidence too.

The viewer provides a file dropdown labelled with knowledge and file names. Each
file shows its sections in source order. Sections supplied to the model have a
brighter border/background and the label **SUPPLIED TO MODEL**; other sections
provide surrounding context. Section IDs and preserved page/line/element ranges
are displayed where available. Text is shown literally, not executed or interpreted
as markup. This is a readable reconstruction, not the original PDF/DOCX layout;
the demo does not launch original files or jump to their pages.

The default view reuses the reconstruction saved with that turn. No model request
or new retrieval is needed, and a saved snapshot remains readable even if the
original knowledge file is later removed. If there is no saved reconstruction,
the viewer calls `Raven.reconstruct_from_turn()` using persisted tool evidence.
This also requires no configured models, but the referenced knowledge data must
still exist.

**Rebuild from saved evidence** explicitly rebuilds against the *current*
knowledge contents. It does not rerun chat or retrieval, overwrite the saved turn,
or promise that edited sources match what the model originally saw. Errors are
shown in the viewer; a previously displayed snapshot remains visible. Close or
Escape cancels an unfinished reconstruction and returns to the conversation.

`/sources` opens the latest source-backed response in the current view. The
per-answer buttons open earlier applicable responses instead. Source
viewing waits until the current chat/ingestion action finishes. If no applicable
answer is present, the command explains that rather than starting a fake operation.

**Highlights identify material supplied to the model—not proof that every claim
in its answer is correct.** This viewer helps the reader check that material.

## Keyboard and mouse controls

- Open a conversation, type a message, and press Enter or click Send. Empty
  messages are ignored; prerequisites are explained if they are missing.
- The unified composer has a multiline editor and internal Attach and Send
  buttons. Shift+Enter inserts a new line (requires a terminal
  that distinguishes Shift+Enter from Enter).
- The editor grows with the draft, then scrolls internally. The chat and composer
  are centered and width-limited in wide terminals.
- Type `/` to open the command menu above the composer. Continue typing without
  spaces to filter by command path, for example `/know` or `/conversations/cr`.
- Up/Down changes the selected command without moving focus out of the editor.
  Enter or clicking a menu entry runs it; Tab completes the path without running
  it. Escape or clicking outside dismisses the menu without deleting the draft.
- Spaces, newlines, and ordinary messages close the menu. No-match input shows a
  notice; Enter still checks the typed path, including resource paths.
- `/help` displays available command paths and shortcuts. Unknown commands show
  an error. Knowledge, model, conversation, and source commands use real RAVEN data.
- Click Attach to choose a knowledge and ingest a local document.
- Tab and Shift+Tab move between focusable controls; Ctrl+L focuses the input.
- Focus the transcript to scroll with Page Up/Page Down, or use the mouse wheel.
- Ctrl+C exits the application.

Send becomes Stop while a response is active. Stopping an ingestion still uses
its separate **Stop ingestion** action.

## Command paths

| Path | Purpose | Current behavior |
| --- | --- | --- |
| `/help` | Show commands and shortcuts | Working locally |
| `/knowledges` | List knowledges | Real backend |
| `/knowledges/create` | Create a knowledge | Inline form → real backend |
| `/knowledges/<name>` | Show knowledge details | Real metadata and file list |
| `/models` | Show configured model pair | Real runtime identities |
| `/models/configure` | Configure models | Inline form and operation progress |
| `/providers/ollama/models` | List installed Ollama models | Real backend, no preload |
| `/knowledges/<name>/ingest` | Ingest a document | Real pipeline, progress, and cancellation |
| `/conversations` | List conversations | Clickable titles, scope, and IDs |
| `/conversations/create` | Create a conversation | Global by default; optional local knowledge |
| `/conversations/<id>` | Open a conversation | Canonical saved history and active scope |
| `/sources` | Inspect reconstructed sources | Latest source-backed response; per-answer buttons also available |

Replace `<name>` and `<id>` with actual values. The popup suggests fixed paths
and discovered knowledge names; `/conversations` provides title-based navigation.
A selected menu command and its directly typed path share the same
submission and routing method.

## Scope and retained data

The demo uses one local user context and runs one backend action at a time.
Retrieval stays in `auto` mode. It does not expose the HTTP server, a runtime
settings editor, resource-deletion controls, an operation-history browser, or
durable retry controls. Submitting a failed request again starts new work; it
does not invoke RAVEN's user-confirmed retry API.

RAVEN's persistence and startup recovery remain active, but this interface does
not schedule operation-history cleanup. Retained history can grow over time.
An application built around RAVEN must choose its retention policy and schedule
the provided `OperationCleanupService` where appropriate.

When sharing the example, include only the source files, stylesheet,
`requirements.txt`, and this README. Exclude `raven_home/`, virtual environments,
`.env` files, credentials, and `__pycache__/`. The application creates a fresh
home automatically when none exists.
